# ExImageViewer
- Navigation
- Fragments
- ViewPager
- Screen Slide

# Resources
- [33 Viewpager2 Transformers for Your Android ui’s](https://medium.com/codex/33-viewpager2-transformers-for-your-android-uis-bbdab801eb2b)
- [Slide between fragments using ViewPager](https://developer.android.com/training/animation/screen-slide#zoom-out)
- [FragmentPagerAdapter with Fragments that restore their state properly](https://medium.com/@pjonceski/fragmentpageradapter-with-fragments-that-restore-their-state-properly-a427ecfd792e)
