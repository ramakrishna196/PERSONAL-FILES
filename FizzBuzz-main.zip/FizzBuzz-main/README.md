# FizzBuzz
Fizz Buzz is a common developer interview question; so common it’s almost cliché!


This is a java project from codecademy
Link: https://www.codecademy.com/courses/learn-java/projects/java-fizzbuzz
