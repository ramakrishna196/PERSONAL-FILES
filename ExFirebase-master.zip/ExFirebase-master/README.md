# ExFirebase
A Firebase and FireStore Example App.

> add your own google-services.json file from "Firebase Project Setting" inside "root/app/"
> and update [web_client_id](https://stackoverflow.com/a/69189013) too 👇
> https://github.com/noobshubham/ExFirebase/blob/edf8fdd45ad6dd47fa6634fa6116080882dd38a1/app/src/main/res/values/strings.xml#L15
