package com.noobshubham.exfirebase.models

data class Profile(
    val email: String = "",
    val uid: String = "",
    val dob: String="",
    val gender: String="",
    val bio: String = "",
    val dp: String = ""
)
