package com.noobshubham.exfirebase.models

data class Message(var text: String = "", val name: String = "")